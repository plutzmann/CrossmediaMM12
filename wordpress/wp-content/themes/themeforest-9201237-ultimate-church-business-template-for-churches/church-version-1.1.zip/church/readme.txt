Our documentation is located in your main download package and we have online Knowledge Base center.
http://support.themewaves.com

Thanks for purchasing.