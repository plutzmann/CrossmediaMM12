<?php get_header(); ?>

<div class="row">
    <?php echo do_shortcode('[tw_portfolio]'); ?>
</div>

<?php get_footer(); ?>