<ul class="unstyled">
    <div class="row fontawesome">
        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-adjust</span><span class="muted">[&amp;#xf042;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-adn</span><span class="muted">[&amp;#xf170;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-align-center</span><span class="muted">[&amp;#xf037;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-align-justify</span><span class="muted">[&amp;#xf039;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-align-left</span><span class="muted">[&amp;#xf036;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-align-right</span><span class="muted">[&amp;#xf038;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ambulance</span><span class="muted">[&amp;#xf0f9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-anchor</span><span class="muted">[&amp;#xf13d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-android</span><span class="muted">[&amp;#xf17b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angellist</span><span class="muted">[&amp;#xf209;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-double-down</span><span class="muted">[&amp;#xf103;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-double-left</span><span class="muted">[&amp;#xf100;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-double-right</span><span class="muted">[&amp;#xf101;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-double-up</span><span class="muted">[&amp;#xf102;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-down</span><span class="muted">[&amp;#xf107;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-left</span><span class="muted">[&amp;#xf104;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-right</span><span class="muted">[&amp;#xf105;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-angle-up</span><span class="muted">[&amp;#xf106;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-apple</span><span class="muted">[&amp;#xf179;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-archive</span><span class="muted">[&amp;#xf187;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-area-chart</span><span class="muted">[&amp;#xf1fe;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-down</span><span class="muted">[&amp;#xf0ab;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-left</span><span class="muted">[&amp;#xf0a8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-o-down</span><span class="muted">[&amp;#xf01a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-o-left</span><span class="muted">[&amp;#xf190;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-o-right</span><span class="muted">[&amp;#xf18e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-o-up</span><span class="muted">[&amp;#xf01b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-right</span><span class="muted">[&amp;#xf0a9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-circle-up</span><span class="muted">[&amp;#xf0aa;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-down</span><span class="muted">[&amp;#xf063;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-left</span><span class="muted">[&amp;#xf060;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-right</span><span class="muted">[&amp;#xf061;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrow-up</span><span class="muted">[&amp;#xf062;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrows</span><span class="muted">[&amp;#xf047;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrows-alt</span><span class="muted">[&amp;#xf0b2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrows-h</span><span class="muted">[&amp;#xf07e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-arrows-v</span><span class="muted">[&amp;#xf07d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-asterisk</span><span class="muted">[&amp;#xf069;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-at</span><span class="muted">[&amp;#xf1fa;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-automobile</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1b9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-backward</span><span class="muted">[&amp;#xf04a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ban</span><span class="muted">[&amp;#xf05e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bank</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf19c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bar-chart</span><span class="muted">[&amp;#xf080;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bar-chart-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf080;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-barcode</span><span class="muted">[&amp;#xf02a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bars</span><span class="muted">[&amp;#xf0c9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-beer</span><span class="muted">[&amp;#xf0fc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-behance</span><span class="muted">[&amp;#xf1b4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-behance-square</span><span class="muted">[&amp;#xf1b5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bell</span><span class="muted">[&amp;#xf0f3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bell-o</span><span class="muted">[&amp;#xf0a2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bell-slash</span><span class="muted">[&amp;#xf1f6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bell-slash-o</span><span class="muted">[&amp;#xf1f7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bicycle</span><span class="muted">[&amp;#xf206;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-binoculars</span><span class="muted">[&amp;#xf1e5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-birthday-cake</span><span class="muted">[&amp;#xf1fd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bitbucket</span><span class="muted">[&amp;#xf171;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bitbucket-square</span><span class="muted">[&amp;#xf172;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bitcoin</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf15a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bold</span><span class="muted">[&amp;#xf032;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bolt</span><span class="muted">[&amp;#xf0e7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bomb</span><span class="muted">[&amp;#xf1e2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-book</span><span class="muted">[&amp;#xf02d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bookmark</span><span class="muted">[&amp;#xf02e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bookmark-o</span><span class="muted">[&amp;#xf097;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-briefcase</span><span class="muted">[&amp;#xf0b1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-btc</span><span class="muted">[&amp;#xf15a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bug</span><span class="muted">[&amp;#xf188;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-building</span><span class="muted">[&amp;#xf1ad;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-building-o</span><span class="muted">[&amp;#xf0f7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bullhorn</span><span class="muted">[&amp;#xf0a1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bullseye</span><span class="muted">[&amp;#xf140;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-bus</span><span class="muted">[&amp;#xf207;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cab</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1ba;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-calculator</span><span class="muted">[&amp;#xf1ec;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-calendar</span><span class="muted">[&amp;#xf073;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-calendar-o</span><span class="muted">[&amp;#xf133;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-camera</span><span class="muted">[&amp;#xf030;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-camera-retro</span><span class="muted">[&amp;#xf083;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-car</span><span class="muted">[&amp;#xf1b9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-down</span><span class="muted">[&amp;#xf0d7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-left</span><span class="muted">[&amp;#xf0d9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-right</span><span class="muted">[&amp;#xf0da;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-square-o-down</span><span class="muted">[&amp;#xf150;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-square-o-left</span><span class="muted">[&amp;#xf191;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-square-o-right</span><span class="muted">[&amp;#xf152;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-square-o-up</span><span class="muted">[&amp;#xf151;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-caret-up</span><span class="muted">[&amp;#xf0d8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc</span><span class="muted">[&amp;#xf20a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-amex</span><span class="muted">[&amp;#xf1f3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-discover</span><span class="muted">[&amp;#xf1f2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-mastercard</span><span class="muted">[&amp;#xf1f1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-paypal</span><span class="muted">[&amp;#xf1f4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-stripe</span><span class="muted">[&amp;#xf1f5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cc-visa</span><span class="muted">[&amp;#xf1f0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-certificate</span><span class="muted">[&amp;#xf0a3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chain</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chain-broken</span><span class="muted">[&amp;#xf127;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-check</span><span class="muted">[&amp;#xf00c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-check-circle</span><span class="muted">[&amp;#xf058;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-check-circle-o</span><span class="muted">[&amp;#xf05d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-check-square</span><span class="muted">[&amp;#xf14a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-check-square-o</span><span class="muted">[&amp;#xf046;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-circle-down</span><span class="muted">[&amp;#xf13a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-circle-left</span><span class="muted">[&amp;#xf137;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-circle-right</span><span class="muted">[&amp;#xf138;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-circle-up</span><span class="muted">[&amp;#xf139;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-down</span><span class="muted">[&amp;#xf078;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-left</span><span class="muted">[&amp;#xf053;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-right</span><span class="muted">[&amp;#xf054;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-chevron-up</span><span class="muted">[&amp;#xf077;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-child</span><span class="muted">[&amp;#xf1ae;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-circle</span><span class="muted">[&amp;#xf111;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-circle-o</span><span class="muted">[&amp;#xf10c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-circle-o-notch</span><span class="muted">[&amp;#xf1ce;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-circle-thin</span><span class="muted">[&amp;#xf1db;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-clipboard</span><span class="muted">[&amp;#xf0ea;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-clock-o</span><span class="muted">[&amp;#xf017;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-close</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf00d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cloud</span><span class="muted">[&amp;#xf0c2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cloud-download</span><span class="muted">[&amp;#xf0ed;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cloud-upload</span><span class="muted">[&amp;#xf0ee;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cny</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf157;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-code</span><span class="muted">[&amp;#xf121;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-code-fork</span><span class="muted">[&amp;#xf126;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-codepen</span><span class="muted">[&amp;#xf1cb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-coffee</span><span class="muted">[&amp;#xf0f4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cog</span><span class="muted">[&amp;#xf013;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cogs</span><span class="muted">[&amp;#xf085;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-columns</span><span class="muted">[&amp;#xf0db;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-comment</span><span class="muted">[&amp;#xf075;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-comment-o</span><span class="muted">[&amp;#xf0e5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-comments</span><span class="muted">[&amp;#xf086;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-comments-o</span><span class="muted">[&amp;#xf0e6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-compass</span><span class="muted">[&amp;#xf14e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-compress</span><span class="muted">[&amp;#xf066;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-copy</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-copyright</span><span class="muted">[&amp;#xf1f9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-credit-card</span><span class="muted">[&amp;#xf09d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-crop</span><span class="muted">[&amp;#xf125;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-crosshairs</span><span class="muted">[&amp;#xf05b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-css3</span><span class="muted">[&amp;#xf13c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cube</span><span class="muted">[&amp;#xf1b2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cubes</span><span class="muted">[&amp;#xf1b3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cut</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-cutlery</span><span class="muted">[&amp;#xf0f5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dashboard</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0e4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-database</span><span class="muted">[&amp;#xf1c0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dedent</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf03b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-delicious</span><span class="muted">[&amp;#xf1a5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-desktop</span><span class="muted">[&amp;#xf108;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-deviantart</span><span class="muted">[&amp;#xf1bd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-digg</span><span class="muted">[&amp;#xf1a6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dollar</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf155;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dot-circle-o</span><span class="muted">[&amp;#xf192;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-download</span><span class="muted">[&amp;#xf019;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dribbble</span><span class="muted">[&amp;#xf17d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-dropbox</span><span class="muted">[&amp;#xf16b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-drupal</span><span class="muted">[&amp;#xf1a9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-edit</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf044;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eject</span><span class="muted">[&amp;#xf052;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ellipsis-h</span><span class="muted">[&amp;#xf141;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ellipsis-v</span><span class="muted">[&amp;#xf142;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-empire</span><span class="muted">[&amp;#xf1d1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-envelope</span><span class="muted">[&amp;#xf0e0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-envelope-o</span><span class="muted">[&amp;#xf003;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-envelope-square</span><span class="muted">[&amp;#xf199;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eraser</span><span class="muted">[&amp;#xf12d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eur</span><span class="muted">[&amp;#xf153;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-euro</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf153;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-exchange</span><span class="muted">[&amp;#xf0ec;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-exclamation</span><span class="muted">[&amp;#xf12a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-exclamation-circle</span><span class="muted">[&amp;#xf06a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-exclamation-triangle</span><span class="muted">[&amp;#xf071;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-expand</span><span class="muted">[&amp;#xf065;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-external-link</span><span class="muted">[&amp;#xf08e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-external-link-square</span><span class="muted">[&amp;#xf14c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eye</span><span class="muted">[&amp;#xf06e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eye-slash</span><span class="muted">[&amp;#xf070;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-eyedropper</span><span class="muted">[&amp;#xf1fb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-facebook</span><span class="muted">[&amp;#xf09a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-facebook-square</span><span class="muted">[&amp;#xf082;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fast-backward</span><span class="muted">[&amp;#xf049;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fast-forward</span><span class="muted">[&amp;#xf050;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fax</span><span class="muted">[&amp;#xf1ac;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-female</span><span class="muted">[&amp;#xf182;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fighter-jet</span><span class="muted">[&amp;#xf0fb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file</span><span class="muted">[&amp;#xf15b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-archive-o</span><span class="muted">[&amp;#xf1c6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-audio-o</span><span class="muted">[&amp;#xf1c7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-code-o</span><span class="muted">[&amp;#xf1c9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-excel-o</span><span class="muted">[&amp;#xf1c3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-image-o</span><span class="muted">[&amp;#xf1c5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-movie-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1c8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-o</span><span class="muted">[&amp;#xf016;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-pdf-o</span><span class="muted">[&amp;#xf1c1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-photo-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1c5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-picture-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1c5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-powerpoint-o</span><span class="muted">[&amp;#xf1c4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-sound-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1c7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-text</span><span class="muted">[&amp;#xf15c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-text-o</span><span class="muted">[&amp;#xf0f6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-video-o</span><span class="muted">[&amp;#xf1c8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-word-o</span><span class="muted">[&amp;#xf1c2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-file-zip-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1c6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-files-o</span><span class="muted">[&amp;#xf0c5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-film</span><span class="muted">[&amp;#xf008;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-filter</span><span class="muted">[&amp;#xf0b0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fire</span><span class="muted">[&amp;#xf06d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-fire-extinguisher</span><span class="muted">[&amp;#xf134;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flag</span><span class="muted">[&amp;#xf024;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flag-checkered</span><span class="muted">[&amp;#xf11e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flag-o</span><span class="muted">[&amp;#xf11d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flash</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0e7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flask</span><span class="muted">[&amp;#xf0c3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-flickr</span><span class="muted">[&amp;#xf16e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-floppy-o</span><span class="muted">[&amp;#xf0c7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-folder</span><span class="muted">[&amp;#xf07b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-folder-o</span><span class="muted">[&amp;#xf114;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-folder-open</span><span class="muted">[&amp;#xf07c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-folder-open-o</span><span class="muted">[&amp;#xf115;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-font</span><span class="muted">[&amp;#xf031;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-forward</span><span class="muted">[&amp;#xf04e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-foursquare</span><span class="muted">[&amp;#xf180;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-frown-o</span><span class="muted">[&amp;#xf119;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-futbol-o</span><span class="muted">[&amp;#xf1e3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gamepad</span><span class="muted">[&amp;#xf11b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gavel</span><span class="muted">[&amp;#xf0e3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gbp</span><span class="muted">[&amp;#xf154;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ge</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1d1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gear</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf013;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gears</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf085;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gift</span><span class="muted">[&amp;#xf06b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-git</span><span class="muted">[&amp;#xf1d3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-git-square</span><span class="muted">[&amp;#xf1d2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-github</span><span class="muted">[&amp;#xf09b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-github-alt</span><span class="muted">[&amp;#xf113;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-github-square</span><span class="muted">[&amp;#xf092;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-gittip</span><span class="muted">[&amp;#xf184;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-glass</span><span class="muted">[&amp;#xf000;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-globe</span><span class="muted">[&amp;#xf0ac;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-google</span><span class="muted">[&amp;#xf1a0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-google-plus</span><span class="muted">[&amp;#xf0d5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-google-plus-square</span><span class="muted">[&amp;#xf0d4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-google-wallet</span><span class="muted">[&amp;#xf1ee;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-graduation-cap</span><span class="muted">[&amp;#xf19d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-group</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-h-square</span><span class="muted">[&amp;#xf0fd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hacker-news</span><span class="muted">[&amp;#xf1d4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hand-o-down</span><span class="muted">[&amp;#xf0a7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hand-o-left</span><span class="muted">[&amp;#xf0a5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hand-o-right</span><span class="muted">[&amp;#xf0a4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hand-o-up</span><span class="muted">[&amp;#xf0a6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hdd-o</span><span class="muted">[&amp;#xf0a0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-header</span><span class="muted">[&amp;#xf1dc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-headphones</span><span class="muted">[&amp;#xf025;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-heart</span><span class="muted">[&amp;#xf004;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-heart-o</span><span class="muted">[&amp;#xf08a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-history</span><span class="muted">[&amp;#xf1da;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-home</span><span class="muted">[&amp;#xf015;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-hospital-o</span><span class="muted">[&amp;#xf0f8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-html5</span><span class="muted">[&amp;#xf13b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ils</span><span class="muted">[&amp;#xf20b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-image</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf03e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-inbox</span><span class="muted">[&amp;#xf01c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-indent</span><span class="muted">[&amp;#xf03c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-info</span><span class="muted">[&amp;#xf129;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-info-circle</span><span class="muted">[&amp;#xf05a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-inr</span><span class="muted">[&amp;#xf156;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-instagram</span><span class="muted">[&amp;#xf16d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-institution</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf19c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ioxhost</span><span class="muted">[&amp;#xf208;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-italic</span><span class="muted">[&amp;#xf033;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-joomla</span><span class="muted">[&amp;#xf1aa;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-jpy</span><span class="muted">[&amp;#xf157;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-jsfiddle</span><span class="muted">[&amp;#xf1cc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-key</span><span class="muted">[&amp;#xf084;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-keyboard-o</span><span class="muted">[&amp;#xf11c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-krw</span><span class="muted">[&amp;#xf159;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-language</span><span class="muted">[&amp;#xf1ab;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-laptop</span><span class="muted">[&amp;#xf109;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-lastfm</span><span class="muted">[&amp;#xf202;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-lastfm-square</span><span class="muted">[&amp;#xf203;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-leaf</span><span class="muted">[&amp;#xf06c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-legal</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0e3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-lemon-o</span><span class="muted">[&amp;#xf094;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-level-down</span><span class="muted">[&amp;#xf149;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-level-up</span><span class="muted">[&amp;#xf148;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-life-bouy</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-life-buoy</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-life-ring</span><span class="muted">[&amp;#xf1cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-life-saver</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-lightbulb-o</span><span class="muted">[&amp;#xf0eb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-line-chart</span><span class="muted">[&amp;#xf201;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-link</span><span class="muted">[&amp;#xf0c1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-linkedin</span><span class="muted">[&amp;#xf0e1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-linkedin-square</span><span class="muted">[&amp;#xf08c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-linux</span><span class="muted">[&amp;#xf17c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-list</span><span class="muted">[&amp;#xf03a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-list-alt</span><span class="muted">[&amp;#xf022;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-list-ol</span><span class="muted">[&amp;#xf0cb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-list-ul</span><span class="muted">[&amp;#xf0ca;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-location-arrow</span><span class="muted">[&amp;#xf124;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-lock</span><span class="muted">[&amp;#xf023;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-long-arrow-down</span><span class="muted">[&amp;#xf175;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-long-arrow-left</span><span class="muted">[&amp;#xf177;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-long-arrow-right</span><span class="muted">[&amp;#xf178;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-long-arrow-up</span><span class="muted">[&amp;#xf176;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-magic</span><span class="muted">[&amp;#xf0d0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-magnet</span><span class="muted">[&amp;#xf076;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mail-forward</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf064;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mail-reply</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf112;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mail-reply-all</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf122;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-male</span><span class="muted">[&amp;#xf183;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-map-marker</span><span class="muted">[&amp;#xf041;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-maxcdn</span><span class="muted">[&amp;#xf136;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-meanpath</span><span class="muted">[&amp;#xf20c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-medkit</span><span class="muted">[&amp;#xf0fa;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-meh-o</span><span class="muted">[&amp;#xf11a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-microphone</span><span class="muted">[&amp;#xf130;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-microphone-slash</span><span class="muted">[&amp;#xf131;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-minus</span><span class="muted">[&amp;#xf068;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-minus-circle</span><span class="muted">[&amp;#xf056;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-minus-square</span><span class="muted">[&amp;#xf146;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-minus-square-o</span><span class="muted">[&amp;#xf147;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mobile</span><span class="muted">[&amp;#xf10b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mobile-phone</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf10b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-money</span><span class="muted">[&amp;#xf0d6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-moon-o</span><span class="muted">[&amp;#xf186;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-mortar-board</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf19d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-music</span><span class="muted">[&amp;#xf001;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-navicon</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-newspaper-o</span><span class="muted">[&amp;#xf1ea;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-openid</span><span class="muted">[&amp;#xf19b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-outdent</span><span class="muted">[&amp;#xf03b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pagelines</span><span class="muted">[&amp;#xf18c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paint-brush</span><span class="muted">[&amp;#xf1fc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paper-plane</span><span class="muted">[&amp;#xf1d8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paper-plane-o</span><span class="muted">[&amp;#xf1d9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paperclip</span><span class="muted">[&amp;#xf0c6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paragraph</span><span class="muted">[&amp;#xf1dd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paste</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0ea;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pause</span><span class="muted">[&amp;#xf04c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paw</span><span class="muted">[&amp;#xf1b0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-paypal</span><span class="muted">[&amp;#xf1ed;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pencil</span><span class="muted">[&amp;#xf040;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pencil-square</span><span class="muted">[&amp;#xf14b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pencil-square-o</span><span class="muted">[&amp;#xf044;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-phone</span><span class="muted">[&amp;#xf095;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-phone-square</span><span class="muted">[&amp;#xf098;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-photo</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf03e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-picture-o</span><span class="muted">[&amp;#xf03e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pie-chart</span><span class="muted">[&amp;#xf200;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pied-piper</span><span class="muted">[&amp;#xf1a7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pied-piper-alt</span><span class="muted">[&amp;#xf1a8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pinterest</span><span class="muted">[&amp;#xf0d2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-pinterest-square</span><span class="muted">[&amp;#xf0d3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plane</span><span class="muted">[&amp;#xf072;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-play</span><span class="muted">[&amp;#xf04b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-play-circle</span><span class="muted">[&amp;#xf144;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-play-circle-o</span><span class="muted">[&amp;#xf01d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plug</span><span class="muted">[&amp;#xf1e6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plus</span><span class="muted">[&amp;#xf067;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plus-circle</span><span class="muted">[&amp;#xf055;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plus-square</span><span class="muted">[&amp;#xf0fe;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-plus-square-o</span><span class="muted">[&amp;#xf196;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-power-off</span><span class="muted">[&amp;#xf011;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-print</span><span class="muted">[&amp;#xf02f;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-puzzle-piece</span><span class="muted">[&amp;#xf12e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-qq</span><span class="muted">[&amp;#xf1d6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-qrcode</span><span class="muted">[&amp;#xf029;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-question</span><span class="muted">[&amp;#xf128;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-question-circle</span><span class="muted">[&amp;#xf059;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-quote-left</span><span class="muted">[&amp;#xf10d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-quote-right</span><span class="muted">[&amp;#xf10e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ra</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1d0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-random</span><span class="muted">[&amp;#xf074;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rebel</span><span class="muted">[&amp;#xf1d0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-recycle</span><span class="muted">[&amp;#xf1b8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-reddit</span><span class="muted">[&amp;#xf1a1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-reddit-square</span><span class="muted">[&amp;#xf1a2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-refresh</span><span class="muted">[&amp;#xf021;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-remove</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf00d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-renren</span><span class="muted">[&amp;#xf18b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-reorder</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-repeat</span><span class="muted">[&amp;#xf01e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-reply</span><span class="muted">[&amp;#xf112;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-reply-all</span><span class="muted">[&amp;#xf122;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-retweet</span><span class="muted">[&amp;#xf079;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rmb</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf157;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-road</span><span class="muted">[&amp;#xf018;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rocket</span><span class="muted">[&amp;#xf135;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rotate-left</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0e2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rotate-right</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf01e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rouble</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf158;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rss</span><span class="muted">[&amp;#xf09e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rss-square</span><span class="muted">[&amp;#xf143;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rub</span><span class="muted">[&amp;#xf158;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ruble</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf158;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-rupee</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf156;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-save</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0c7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-scissors</span><span class="muted">[&amp;#xf0c4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-search</span><span class="muted">[&amp;#xf002;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-search-minus</span><span class="muted">[&amp;#xf010;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-search-plus</span><span class="muted">[&amp;#xf00e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-send</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1d8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-send-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1d9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-share</span><span class="muted">[&amp;#xf064;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-share-alt</span><span class="muted">[&amp;#xf1e0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-share-alt-square</span><span class="muted">[&amp;#xf1e1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-share-square</span><span class="muted">[&amp;#xf14d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-share-square-o</span><span class="muted">[&amp;#xf045;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-shekel</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf20b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sheqel</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf20b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-shield</span><span class="muted">[&amp;#xf132;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-shopping-cart</span><span class="muted">[&amp;#xf07a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sign-in</span><span class="muted">[&amp;#xf090;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sign-out</span><span class="muted">[&amp;#xf08b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-signal</span><span class="muted">[&amp;#xf012;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sitemap</span><span class="muted">[&amp;#xf0e8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-skype</span><span class="muted">[&amp;#xf17e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-slack</span><span class="muted">[&amp;#xf198;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sliders</span><span class="muted">[&amp;#xf1de;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-slideshare</span><span class="muted">[&amp;#xf1e7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-smile-o</span><span class="muted">[&amp;#xf118;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-soccer-ball-o</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1e3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort</span><span class="muted">[&amp;#xf0dc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-alpha-asc</span><span class="muted">[&amp;#xf15d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-alpha-desc</span><span class="muted">[&amp;#xf15e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-amount-asc</span><span class="muted">[&amp;#xf160;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-amount-desc</span><span class="muted">[&amp;#xf161;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-asc</span><span class="muted">[&amp;#xf0de;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-desc</span><span class="muted">[&amp;#xf0dd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-down</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0dd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-numeric-asc</span><span class="muted">[&amp;#xf162;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-numeric-desc</span><span class="muted">[&amp;#xf163;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sort-up</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0de;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-soundcloud</span><span class="muted">[&amp;#xf1be;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-space-shuttle</span><span class="muted">[&amp;#xf197;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-spinner</span><span class="muted">[&amp;#xf110;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-spoon</span><span class="muted">[&amp;#xf1b1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-spotify</span><span class="muted">[&amp;#xf1bc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-square</span><span class="muted">[&amp;#xf0c8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-square-o</span><span class="muted">[&amp;#xf096;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stack-exchange</span><span class="muted">[&amp;#xf18d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stack-overflow</span><span class="muted">[&amp;#xf16c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star</span><span class="muted">[&amp;#xf005;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star-half</span><span class="muted">[&amp;#xf089;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star-half-empty</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf123;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star-half-full</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf123;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star-half-o</span><span class="muted">[&amp;#xf123;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-star-o</span><span class="muted">[&amp;#xf006;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-steam</span><span class="muted">[&amp;#xf1b6;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-steam-square</span><span class="muted">[&amp;#xf1b7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-step-backward</span><span class="muted">[&amp;#xf048;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-step-forward</span><span class="muted">[&amp;#xf051;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stethoscope</span><span class="muted">[&amp;#xf0f1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stop</span><span class="muted">[&amp;#xf04d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-strikethrough</span><span class="muted">[&amp;#xf0cc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stumbleupon</span><span class="muted">[&amp;#xf1a4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-stumbleupon-circle</span><span class="muted">[&amp;#xf1a3;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-subscript</span><span class="muted">[&amp;#xf12c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-suitcase</span><span class="muted">[&amp;#xf0f2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-sun-o</span><span class="muted">[&amp;#xf185;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-superscript</span><span class="muted">[&amp;#xf12b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-support</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-table</span><span class="muted">[&amp;#xf0ce;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tablet</span><span class="muted">[&amp;#xf10a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tachometer</span><span class="muted">[&amp;#xf0e4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tag</span><span class="muted">[&amp;#xf02b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tags</span><span class="muted">[&amp;#xf02c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tasks</span><span class="muted">[&amp;#xf0ae;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-taxi</span><span class="muted">[&amp;#xf1ba;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tencent-weibo</span><span class="muted">[&amp;#xf1d5;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-terminal</span><span class="muted">[&amp;#xf120;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-text-height</span><span class="muted">[&amp;#xf034;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-text-width</span><span class="muted">[&amp;#xf035;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-th</span><span class="muted">[&amp;#xf00a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-th-large</span><span class="muted">[&amp;#xf009;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-th-list</span><span class="muted">[&amp;#xf00b;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-thumb-tack</span><span class="muted">[&amp;#xf08d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-thumbs-down</span><span class="muted">[&amp;#xf165;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-thumbs-o-down</span><span class="muted">[&amp;#xf088;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-thumbs-o-up</span><span class="muted">[&amp;#xf087;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-thumbs-up</span><span class="muted">[&amp;#xf164;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-ticket</span><span class="muted">[&amp;#xf145;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-times</span><span class="muted">[&amp;#xf00d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-times-circle</span><span class="muted">[&amp;#xf057;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-times-circle-o</span><span class="muted">[&amp;#xf05c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tint</span><span class="muted">[&amp;#xf043;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-down</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf150;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-left</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf191;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-off</span><span class="muted">[&amp;#xf204;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-on</span><span class="muted">[&amp;#xf205;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-right</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf152;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-toggle-up</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf151;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-trash</span><span class="muted">[&amp;#xf1f8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-trash-o</span><span class="muted">[&amp;#xf014;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tree</span><span class="muted">[&amp;#xf1bb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-trello</span><span class="muted">[&amp;#xf181;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-trophy</span><span class="muted">[&amp;#xf091;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-truck</span><span class="muted">[&amp;#xf0d1;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-try</span><span class="muted">[&amp;#xf195;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tty</span><span class="muted">[&amp;#xf1e4;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tumblr</span><span class="muted">[&amp;#xf173;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-tumblr-square</span><span class="muted">[&amp;#xf174;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-turkish-lira</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf195;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-twitch</span><span class="muted">[&amp;#xf1e8;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-twitter</span><span class="muted">[&amp;#xf099;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-twitter-square</span><span class="muted">[&amp;#xf081;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-umbrella</span><span class="muted">[&amp;#xf0e9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-underline</span><span class="muted">[&amp;#xf0cd;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-undo</span><span class="muted">[&amp;#xf0e2;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-university</span><span class="muted">[&amp;#xf19c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-unlink</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf127;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-unlock</span><span class="muted">[&amp;#xf09c;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-unlock-alt</span><span class="muted">[&amp;#xf13e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-unsorted</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf0dc;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-upload</span><span class="muted">[&amp;#xf093;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-usd</span><span class="muted">[&amp;#xf155;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-user</span><span class="muted">[&amp;#xf007;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-user-md</span><span class="muted">[&amp;#xf0f0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-users</span><span class="muted">[&amp;#xf0c0;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-video-camera</span><span class="muted">[&amp;#xf03d;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-vimeo-square</span><span class="muted">[&amp;#xf194;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-vine</span><span class="muted">[&amp;#xf1ca;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-vk</span><span class="muted">[&amp;#xf189;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-volume-down</span><span class="muted">[&amp;#xf027;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-volume-off</span><span class="muted">[&amp;#xf026;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-volume-up</span><span class="muted">[&amp;#xf028;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-warning</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf071;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-wechat</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf1d7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-weibo</span><span class="muted">[&amp;#xf18a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-weixin</span><span class="muted">[&amp;#xf1d7;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-wheelchair</span><span class="muted">[&amp;#xf193;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-wifi</span><span class="muted">[&amp;#xf1eb;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-windows</span><span class="muted">[&amp;#xf17a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-won</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf159;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-wordpress</span><span class="muted">[&amp;#xf19a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-wrench</span><span class="muted">[&amp;#xf0ad;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-xing</span><span class="muted">[&amp;#xf168;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-xing-square</span><span class="muted">[&amp;#xf169;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-yahoo</span><span class="muted">[&amp;#xf19e;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-yelp</span><span class="muted">[&amp;#xf1e9;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-yen</span><span class="text-muted">(alias)</span><span class="muted">[&amp;#xf157;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-youtube</span><span class="muted">[&amp;#xf167;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-youtube-play</span><span class="muted">[&amp;#xf16a;]</span></div>

        <div class="col-sm-6 col-lg-3 col-md-3"><i class="fa fa-fw"></i><span class="muted">fa-youtube-square</span><span class="muted">[&amp;#xf166;]</span></div>

    </div>
    <div class="row simple-line-icons">

        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-user"></i><span class="muted">
                icon-user
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-user-female"></i><span class="muted">
                icon-user-female
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-users"></i><span class="muted">
                icon-users
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-user-follow"></i><span class="muted">
                icon-user-follow
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-user-unfollow"></i><span class="muted">
                icon-user-unfollow
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-trophy"></i><span class="muted">
                icon-trophy
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-speedometer"></i><span class="muted">
                icon-speedometer
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-youtube"></i><span class="muted">
                icon-social-youtube
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-twitter"></i><span class="muted">
                icon-social-twitter
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-tumblr"></i><span class="muted">
                icon-social-tumblr
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-facebook"></i><span class="muted">
                icon-social-facebook
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-dropbox"></i><span class="muted">
                icon-social-dropbox
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-social-dribbble"></i><span class="muted">
                icon-social-dribbble
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-shield"></i><span class="muted">
                icon-shield
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-screen-tablet"></i><span class="muted">
                icon-screen-tablet
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-screen-smartphone"></i><span class="muted">
                icon-screen-smartphone
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-screen-desktop"></i><span class="muted">
                icon-screen-desktop
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-plane"></i><span class="muted">
                icon-plane
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-notebook"></i><span class="muted">
                icon-notebook
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-moustache"></i><span class="muted">
                icon-moustache
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-mouse"></i><span class="muted">
                icon-mouse
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-magnet"></i><span class="muted">
                icon-magnet
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-magic-wand"></i><span class="muted">
                icon-magic-wand
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-hourglass"></i><span class="muted">
                icon-hourglass
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-graduation"></i><span class="muted">
                icon-graduation
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-ghost"></i><span class="muted">
                icon-ghost
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-game-controller"></i><span class="muted">
                icon-game-controller
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-fire"></i><span class="muted">
                icon-fire
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-eyeglasses"></i><span class="muted">
                icon-eyeglasses
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-envelope-open"></i><span class="muted">
                icon-envelope-open
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-envelope-letter"></i><span class="muted">
                icon-envelope-letter
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-energy"></i><span class="muted">
                icon-energy
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-emoticon-smile"></i><span class="muted">
                icon-emoticon-smile
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-disc"></i><span class="muted">
                icon-disc
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-cursor-move"></i><span class="muted">
                icon-cursor-move
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-crop"></i><span class="muted">
                icon-crop
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-credit-card"></i><span class="muted">
                icon-credit-card
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-chemistry"></i><span class="muted">
                icon-chemistry
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bell"></i><span class="muted">
                icon-bell
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-badge"></i><span class="muted">
                icon-badge
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-anchor"></i><span class="muted">
                icon-anchor
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-action-redo"></i><span class="muted">
                icon-action-redo
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-action-undo"></i><span class="muted">
                icon-action-undo
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bag"></i><span class="muted">
                icon-bag
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-ghost"></i><span class="muted">
                icon-ghost
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-basket"></i><span class="muted">
                icon-basket
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-basket-loaded"></i><span class="muted">
                icon-basket-loaded
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-book-open"></i><span class="muted">
                icon-book-open
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-briefcase"></i><span class="muted">
                icon-briefcase
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bubbles"></i><span class="muted">
                icon-bubbles
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-calculator"></i><span class="muted">
                icon-calculator
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-call-end"></i><span class="muted">
                icon-call-end
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-call-in"></i><span class="muted">
                icon-call-in
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-call-out"></i><span class="muted">
                icon-call-out
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-compass"></i><span class="muted">
                icon-compass
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-cup"></i><span class="muted">
                icon-cup
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-diamond"></i><span class="muted">
                icon-diamond
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-direction"></i><span class="muted">
                icon-direction
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-directions"></i><span class="muted">
                icon-directions
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-ghost"></i><span class="muted">
                icon-ghost
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-docs"></i><span class="muted">
                icon-docs
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-drawer"></i><span class="muted">
                icon-drawer
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-drop"></i><span class="muted">
                icon-drop
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-earphones"></i><span class="muted">
                icon-earphones
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-earphones-alt"></i><span class="muted">
                icon-earphones-alt
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-feed"></i><span class="muted">
                icon-feed
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-film"></i><span class="muted">
                icon-film
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-folder-alt"></i><span class="muted">
                icon-folder-alt
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-frame"></i><span class="muted">
                icon-frame
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-globe"></i><span class="muted">
                icon-globe
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-globe-alt"></i><span class="muted">
                icon-globe-alt
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-handbag"></i><span class="muted">
                icon-handbag
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-layers"></i><span class="muted">
                icon-layers
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-map"></i><span class="muted">
                icon-map
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-picture"></i><span class="muted">
                icon-picture
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pin"></i><span class="muted">
                icon-pin
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-playlist"></i><span class="muted">
                icon-playlist
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-present"></i><span class="muted">
                icon-present
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-printer"></i><span class="muted">
                icon-printer
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-puzzle"></i><span class="muted">
                icon-puzzle
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-speech"></i><span class="muted">
                icon-speech
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-vector"></i><span class="muted">
                icon-vector
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-wallet"></i><span class="muted">
                icon-wallet
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-arrow-down"></i><span class="muted">
                icon-arrow-down
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-arrow-left"></i><span class="muted">
                icon-arrow-left
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-arrow-right"></i><span class="muted">
                icon-arrow-right
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-arrow-up"></i><span class="muted">
                icon-arrow-up
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bar-chart"></i><span class="muted">
                icon-bar-chart
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bulb"></i><span class="muted">
                icon-bulb
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-calendar"></i><span class="muted">
                icon-calendar
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-end"></i><span class="muted">
                icon-control-end
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-forward"></i><span class="muted">
                icon-control-forward
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-pause"></i><span class="muted">
                icon-control-pause
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-play"></i><span class="muted">
                icon-control-play
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-rewind"></i><span class="muted">
                icon-control-rewind
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-control-start"></i><span class="muted">
                icon-control-start
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-cursor"></i><span class="muted">
                icon-cursor
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-dislike"></i><span class="muted">
                icon-dislike
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-equalizer"></i><span class="muted">
                icon-equalizer
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-graph"></i><span class="muted">
                icon-graph
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-grid"></i><span class="muted">
                icon-grid
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-home"></i><span class="muted">
                icon-home
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-like"></i><span class="muted">
                icon-like
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-list"></i><span class="muted">
                icon-list
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-login"></i><span class="muted">
                icon-login
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-logout"></i><span class="muted">
                icon-logout
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-loop"></i><span class="muted">
                icon-loop
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-microphone"></i><span class="muted">
                icon-microphone
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-music-tone"></i><span class="muted">
                icon-music-tone
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-music-tone-alt"></i><span class="muted">
                icon-music-tone-alt
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-note"></i><span class="muted">
                icon-note
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pencil"></i><span class="muted">
                icon-pencil
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pie-chart"></i><span class="muted">
                icon-pie-chart
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-question"></i><span class="muted">
                icon-question
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-rocket"></i><span class="muted">
                icon-rocket
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-share"></i><span class="muted">
                icon-share
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-share-alt"></i><span class="muted">
                icon-share-alt
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-shuffle"></i><span class="muted">
                icon-shuffle
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-size-actual"></i><span class="muted">
                icon-size-actual
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-size-fullscreen"></i><span class="muted">
                icon-size-fullscreen
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-support"></i><span class="muted">
                icon-support
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-tag"></i><span class="muted">
                icon-tag
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pencil"></i><span class="muted">
                icon-trash
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pencil"></i><span class="muted">
                icon-trash
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-umbrella"></i><span class="muted">
                icon-umbrella
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-wrench"></i><span class="muted">
                icon-wrench
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-ban"></i><span class="muted">
                icon-ban
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-bubble"></i><span class="muted">
                icon-bubble
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-camcorder"></i><span class="muted">
                icon-camcorder
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-camera"></i><span class="muted">
                icon-camera
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-check"></i><span class="muted">
                icon-check
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-clock"></i><span class="muted">
                icon-clock
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-close"></i><span class="muted">
                icon-close
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-cloud-download"></i><span class="muted">
                icon-cloud-download
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-cloud-upload"></i><span class="muted">
                icon-cloud-upload
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-doc"></i><span class="muted">
                icon-doc
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-envelope"></i><span class="muted">
                icon-envelope
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-eye"></i><span class="muted">
                icon-eye
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-flag"></i><span class="muted">
                icon-flag
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-folder"></i><span class="muted">
                icon-folder
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-heart"></i><span class="muted">
                icon-heart
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-info"></i><span class="muted">
                icon-info
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-key"></i><span class="muted">
                icon-key
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-link"></i><span class="muted">
                icon-link
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-lock"></i><span class="muted">
                icon-lock
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-lock-open"></i><span class="muted">
                icon-lock-open
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-magnifier"></i><span class="muted">
                icon-magnifier
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-magnifier-add"></i><span class="muted">
                icon-magnifier-add
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-magnifier-remove"></i><span class="muted">
                icon-magnifier-remove
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-paper-clip"></i><span class="muted">
                icon-paper-clip
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-paper-plane"></i><span class="muted">
                icon-paper-plane
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-plus"></i><span class="muted">
                icon-plus
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-pointer"></i><span class="muted">
                icon-pointer
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-power"></i><span class="muted">
                icon-power
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-refresh"></i><span class="muted">
                icon-refresh
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-reload"></i><span class="muted">
                icon-reload
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-settings"></i><span class="muted">
                icon-settings
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-star"></i><span class="muted">
                icon-star
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-symbol-female"></i><span class="muted">
                icon-symbol-female
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-symbol-male"></i><span class="muted">
                icon-symbol-male
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-target"></i><span class="muted">
                icon-target
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-volume-1"></i><span class="muted">
                icon-volume-1
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-volume-2"></i><span class="muted">
                icon-volume-2
            </span>
        </div>
        <div class="col-md-3 col-sm-6 col-lg-3">
            <i class="icon-volume-off"></i><span class="muted">
                icon-volume-off
            </span>
        </div>
        
    </div>
</ul>