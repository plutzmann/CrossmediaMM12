<?php
global $waves_elements;
$waves_elements["content"] = array(
    "name" => "Content",
    "size" => "col-md-12",
    "only" => "builder",
    "help" => "http://support.themewaves.com/knowledgebase/content-element-tutorial/",
    "settings" => array(
        "description" => array(
            "title" => "This element displays content of your Core Editor. If you want to use additional Editor Please use the Column Element on our Page builder",
            "type" => "button",
            "data" => array(),
            "default" => "",
            "desc" => "",
        ),
    ),
);