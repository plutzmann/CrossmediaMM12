<?php
global $waves_elements;
$waves_elements["bottom"] = array(
    "name" => "Bottom",
    "size" => "col-md-12",
    "min-size" => "col-md-12",
    "only" => "builder",
    "help" => "http://support.themewaves.com/knowledgebase/content-element-tutorial/",
    "settings" => array(
        "description" => array(
            "title" => "This element displays bottom widget.",
            "type" => "button",
            "data" => array(),
            "default" => "",
            "desc" => "",
        ),
    ),
);