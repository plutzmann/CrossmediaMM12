<?php 
// Insert your Customization Functions. Read More - http://codex.wordpress.org/Child_Themes


?>